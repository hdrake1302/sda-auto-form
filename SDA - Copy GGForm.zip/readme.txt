Hướng dẫn cài đặt:
B1: Search bằng Google Chrome: chrome://extensions/
B2: Nhấn vào "Developer mode".
B3: Nhấn "Load unpacked" và tìm đến thư mục chứa extension.
B4: Nhấn "Select Folder"

Hướng dẫn sử dụng:
B1: Nhấn vào icon bên góc phải trên cùng màn hình
B2: Sang trang form đáp án cho sẵn nhấn nút Copy
B3: Sang trang form của mình nhấn nút paste
B4: Nếu đáp án đã được tự động tick nghĩa là đã copy thành công.

Chúc bạn sử dụng vui vẻ nha <3

Link test form: https://forms.gle/TBt4iy1uq5vJhtmZA

Tính năng SDA - Auto Form 3.1:
- Copy form đang làm
- Copy form kết quả (có thể bỏ qua câu sai)

- Nhập vào key code được share vào SDA-Auto Form
- Paste đáp án từ keys đã được copy

- Share đáp án với người khác 
bằng text hoặc key code 


Example of Key Code: 
{"Câu hỏi \"đặc biệt\"":"B","Câu hỏi 1":"A","Câu hỏi 10":"A","Câu hỏi 2":"A","Câu hỏi 3":"A","Câu hỏi 4":"A","Câu hỏi 5":"A","Câu hỏi 6":"C","Câu hỏi 7":"C","Câu hỏi 8":"C","Câu hỏi 9":"A","Câu hỏi đặc biệt 2":["B"],"Câu hỏi đặc biệt 3":["C","D"],"Câu hỏi đặc biệt 4":["A","D"],"SDA viết tắt cho từ gì ?":"Share đáp án","TDT viết tắt cho từ gì":"Tôn Đức Thắng"}
